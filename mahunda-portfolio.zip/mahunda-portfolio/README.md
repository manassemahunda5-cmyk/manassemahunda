# Manasse Mahunda (Msongz) - Portfolio

Static portfolio website (HTML, CSS, JavaScript). No build step, no framework, so it deploys to Vercel as-is.

## What is in this project

```
index.html                              the whole page (intro, hero, about, stats, work, experience,
                                        certifications, process, pin-a-note board, contact, footer)
assets/
  css/style.css                         main styles
  js/main.js                            animations, footer physics (drag / throw / kick), local notes fallback
  js/matter.min.js                      Matter.js physics engine (MIT)
  img/                                  hero.webp, about.jpg, logo.jpg, certificate-*.jpg
  favicon.svg
Manasse_Mahunda_CV.pdf / .docx          CV (PDF to view, Word file to open in WPS / Word)
Manasse_Mahunda_*_Certificate.pdf       the four certificates opened by "View certificate"
database/setup.sql                      one-time Supabase setup for the shared Pin a Note board
vercel.json, package.json, robots.txt   deployment and project files
```

Note: the certificate preview images are also embedded inside `index.html`, so they show even if the
`assets/img/certificate-*.jpg` files are missing.

## Open it in VS Code

1. Unzip the folder, then in VS Code choose **File > Open Folder** and pick `mahunda-portfolio`.
2. VS Code will suggest the **Live Server** extension. Install it.
3. Right-click `index.html` and choose **Open with Live Server**. The site opens in your browser
   and refreshes every time you save.

No Live Server? Run `npx serve .` in the VS Code terminal, or just double-click `index.html`.

## Where to change things

- Text, jobs, certificates, stats: `index.html` (search for the words you want to change).
- Colours: the `:root` variables at the top of `assets/css/style.css`
  (royal blue `#1455B5`, white `#FFFFFF`, black `#000000`).
- Intro animation timing: the `T_GUN`, `T_SHOT` constants in the `intro-stats-js` script near the end of `index.html`.
- Contact details: search for `09121333315`, `08124350795` and `manassethewebdesigner@gmail.com` in `index.html`.

## Shared Pin a Note board (Supabase)

Notes are stored in a free Supabase database so every visitor sees them.

- Run `database/setup.sql` once in Supabase (SQL Editor) after changing the passcode inside it.
- The project URL and public (publishable) key are in `index.html`, in `window.NOTES_CFG`.
- To delete a note, open the live site with `?admin=1` on the end of the address, enter your passcode,
  and tap the red Delete button on a note.

## Deploy: GitHub, then Vercel

1. Upload the project to a GitHub repository (all files at the top level, or with the `assets` folder kept intact).
2. In Vercel choose **Add New > Project**, import the repository and press **Deploy**. No settings are needed.

Fonts (Anton, Manrope, DM Mono, Caveat, Reenie Beanie, Exo 2) load from Google Fonts, so an internet
connection is needed to see them while editing.
