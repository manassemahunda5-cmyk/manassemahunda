-- Manasse portfolio: shared "Pin a Note" board
-- Paste this whole file into Supabase > SQL Editor > New query > Run.
-- BEFORE running: change CHOOSE-YOUR-OWN-PASSCODE (last block) to a passcode only you know.

create table if not exists public.notes (
  id         bigint generated always as identity primary key,
  text       text not null check (char_length(text) between 1 and 120),
  name       text check (char_length(name) <= 24),
  color      text not null default '#CFE0F7' check (color ~ '^#[0-9A-Fa-f]{6}$'),
  rot        real not null default 0,
  x          int  not null default 10,
  y          int  not null default 10,
  created_at timestamptz not null default now()
);

alter table public.notes enable row level security;

-- everyone can read notes and add notes. Nobody can edit or delete directly.
drop policy if exists "anyone can read"  on public.notes;
drop policy if exists "anyone can add"   on public.notes;
create policy "anyone can read" on public.notes for select using (true);
create policy "anyone can add"  on public.notes for insert with check (char_length(text) between 1 and 120);

-- the admin passcode lives in a table that visitors cannot read
create table if not exists public.admin_secret (pass text not null);
alter table public.admin_secret enable row level security;
delete from public.admin_secret;
insert into public.admin_secret (pass) values ('CHOOSE-YOUR-OWN-PASSCODE');

-- only someone who knows the passcode can delete a note
create or replace function public.delete_note(note_id bigint, passcode text)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.admin_secret where pass = passcode) then
    delete from public.notes where id = note_id;
    return true;
  end if;
  return false;
end $$;
grant execute on function public.delete_note(bigint, text) to anon;
